An overview of most of the trading strategies in this folder can be found in the 
`Examples Algorithms <https://enigmampc.github.io/catalyst/example-algos.html>`_
section of our documentation website.